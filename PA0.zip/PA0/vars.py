#
# vars.py
#
# This file contains global variables for route-finding search.
#
# David Noelle - Mon Sep 19 21:23:15 PDT 2022
#

# Number of nodes expanded during a search ...
node_expansion_count = 0
